//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by staff.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_STAFF_DIALOG                102
#define IDR_MAINFRAME                   128
#define IDD_NEW_IP_SOLUTION             129
#define IDC_NEEDS_MON                   1000
#define IDC_NEWIP_ITERATION             1000
#define IDC_NEEDS_TUE                   1001
#define IDC_NEWIP_OBJECTIVE             1001
#define IDC_NEEDS_WED                   1002
#define IDC_NEWIP_BOUND                 1002
#define IDC_NEEDS_THU                   1003
#define IDC_NEEDS_FRI                   1004
#define IDC_NEEDS_SAT                   1005
#define IDC_NEEDS_SUN                   1006
#define IDC_START_MON                   1030
#define IDC_START_TUE                   1031
#define IDC_START_WED                   1032
#define IDC_START_THU                   1033
#define IDC_START_FRI                   1034
#define IDC_START_SAT                   1035
#define IDC_START_SUN                   1036
#define IDC_COST                        1037
#define IDC_ON_MON                      1038
#define IDC_ON_TUE                      1039
#define IDC_ON_WED                      1040
#define IDC_ON_THU                      1041
#define IDC_ON_FRI                      1042
#define IDC_ON_SAT                      1043
#define IDC_ON_SUN                      1044

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
